package com.example.myapplication

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen() {
    var inputValue by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        TextField(
            value = inputValue,
            onValueChange = { inputValue = it },
            label = { Text("Ingrese un valor") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { fetchKleeneStar(inputValue) }) {
            Text("Calcular Kleene Star")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Resultado: $result")
    }
}
